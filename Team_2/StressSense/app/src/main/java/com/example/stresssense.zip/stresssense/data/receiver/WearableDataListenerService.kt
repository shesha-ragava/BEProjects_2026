package com.example.stresssense.data.receiver

import android.util.Log
import com.example.stresssense.data.local.SensorData
import com.example.stresssense.data.local.SensorDataDao
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.WearableListenerService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class WearableDataListenerService : WearableListenerService() {

    @Inject
    lateinit var sensorDataDao: SensorDataDao

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    override fun onDataChanged(dataEvents: DataEventBuffer) {
        super.onDataChanged(dataEvents)

        dataEvents.filter { it.type == DataEvent.TYPE_CHANGED && it.dataItem.uri.path == SENSOR_DATA_PATH }
            .forEach { event ->
                val dataMap = DataMapItem.fromDataItem(event.dataItem).dataMap
                val motionValues = dataMap.getFloatArray(KEY_MOTION) ?: floatArrayOf(0f, 0f, 0f)

                val sensorData = SensorData(
                    timestamp = dataMap.getLong("timestamp"),
                    heartRate = dataMap.getDouble(KEY_HEART_RATE),
                    steps = dataMap.getLong(KEY_STEPS),
                    motionX = motionValues.getOrElse(0) { 0f },
                    motionY = motionValues.getOrElse(1) { 0f },
                    motionZ = motionValues.getOrElse(2) { 0f }
                )

                serviceScope.launch {
                    try {
                        sensorDataDao.insert(sensorData)
                        Log.d(TAG, "Inserted new sensor data: $sensorData")
                    } catch (e: Exception) {
                        Log.e(TAG, "Error inserting sensor data", e)
                    }
                }
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }

    companion object {
        private const val TAG = "DataListenerService"

        // Keys to match the Wear OS service
        private const val SENSOR_DATA_PATH = "/sensor_data"
        private const val KEY_HEART_RATE = "heart_rate"
        private const val KEY_STEPS = "steps"
        private const val KEY_MOTION = "motion"
    }
}
