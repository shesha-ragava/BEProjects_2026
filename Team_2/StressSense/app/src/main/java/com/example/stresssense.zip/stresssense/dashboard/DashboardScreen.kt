package com.example.stresssense.dashboard

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.stresssense.Screen

@Composable
fun DashboardScreen(
    modifier: Modifier = Modifier,
    viewModel: DashboardViewModel = hiltViewModel(),
    onNavigate: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        StressGauge(stressLevel = uiState.currentStressLevel)
        Spacer(Modifier.height(16.dp))
        InfoCards(steps = uiState.todaySteps, sleep = uiState.todaySleep)
        Spacer(Modifier.height(16.dp))
        StressTrendGraph(
            weeklyData = uiState.weeklyStressData,
            monthlyData = uiState.monthlyStressData
        )
        Spacer(Modifier.height(16.dp))
        ActionButtons(onNavigate = onNavigate)
    }
}

@Composable
private fun StressGauge(stressLevel: Float) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Live Stress Level", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(16.dp))
            // A simple circular gauge
            Canvas(modifier = Modifier.size(150.dp)) {
                drawArc(
                    color = Color.LightGray,
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 15f, cap = StrokeCap.Round)
                )
                drawArc(
                    color = Color.Red,
                    startAngle = 135f,
                    sweepAngle = 270f * stressLevel,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 15f, cap = StrokeCap.Round)
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = "${(stressLevel * 100).toInt()}%",
                style = MaterialTheme.typography.headlineLarge
            )
        }
    }
}

@Composable
private fun InfoCards(steps: Long, sleep: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(modifier = Modifier.weight(1f)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Today's Steps", style = MaterialTheme.typography.titleMedium)
                Text(steps.toString(), style = MaterialTheme.typography.bodyLarge)
            }
        }
        Card(modifier = Modifier.weight(1f)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Today's Sleep", style = MaterialTheme.typography.titleMedium)
                Text(sleep, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Composable
private fun StressTrendGraph(weeklyData: List<Float>, monthlyData: List<Float>) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Weekly", "Monthly")

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            // Simple line graph
            val data = if (selectedTab == 0) weeklyData else monthlyData
            if (data.isNotEmpty()) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                ) {
                    val spacing = size.width / (data.size - 1).toFloat()
                    for (i in 0 until data.size - 1) {
                        drawLine(
                            color = Color.Blue,
                            start = Offset(i * spacing, size.height * (1 - data[i])),
                            end = Offset((i + 1) * spacing, size.height * (1 - data[i + 1])),
                            strokeWidth = 5f
                        )
                    }
                }
            } else {
                Text("No data available", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun ActionButtons(onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(onClick = { onNavigate(Screen.Relax.route) }, modifier = Modifier.fillMaxWidth()) {
            Text("Relax")
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = { onNavigate(Screen.Sos.route) }, modifier = Modifier.weight(1f)) {
                Text("SOS")
            }
            Button(onClick = { onNavigate(Screen.Hospitals.route) }, modifier = Modifier.weight(1f)) {
                Text("Nearby Hospitals")
            }
        }
    }
}
