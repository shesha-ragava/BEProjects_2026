package com.example.stresssense.relax

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

private const val INHALE_DURATION = 4000L
private const val HOLD_DURATION = 2000L
private const val EXHALE_DURATION = 6000L

private enum class BreathingState {
    Inhale, Hold, Exhale
}

@Composable
fun BreathingExerciseScreen() {
    var breathingState by remember { mutableStateOf(BreathingState.Inhale) }
    var timer by remember { mutableStateOf(INHALE_DURATION / 1000) }
    val transition = rememberInfiniteTransition()

    val size by transition.animateFloat(
        initialValue = 100f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = INHALE_DURATION.toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    LaunchedEffect(Unit) {
        while (true) {
            // Inhale
            breathingState = BreathingState.Inhale
            for (i in (INHALE_DURATION / 1000) downTo 1) {
                timer = i
                delay(1000)
            }

            // Hold
            breathingState = BreathingState.Hold
            for (i in (HOLD_DURATION / 1000) downTo 1) {
                timer = i
                delay(1000)
            }

            // Exhale
            breathingState = BreathingState.Exhale
            for (i in (EXHALE_DURATION / 1000) downTo 1) {
                timer = i
                delay(1000)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(modifier = Modifier.fillMaxSize(0.5f)) {
            drawCircle(
                color = Color.Blue.copy(alpha = 0.5f),
                radius = size,
                center = Offset(this.size.width / 2, this.size.height / 2)
            )
        }
        Spacer(modifier = Modifier.height(32.dp))
        Text(text = breathingState.name, style = MaterialTheme.typography.headlineMedium)
        Text(text = timer.toString(), style = MaterialTheme.typography.headlineLarge)
    }
}
