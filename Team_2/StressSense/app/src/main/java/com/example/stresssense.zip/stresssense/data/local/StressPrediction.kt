package com.example.stresssense.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stress_predictions")
data class StressPrediction(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val timestamp: Long,
    val stressScore: Float
)
