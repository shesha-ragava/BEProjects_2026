package com.example.stresssense.dashboard

data class DashboardUiState(
    val currentStressLevel: Float = 0f,
    val todaySteps: Long = 0L,
    val todaySleep: String = "N/A",
    val weeklyStressData: List<Float> = emptyList(),
    val monthlyStressData: List<Float> = emptyList()
)
