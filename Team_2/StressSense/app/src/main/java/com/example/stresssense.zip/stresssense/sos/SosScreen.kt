package com.example.stresssense.sos

import android.Manifest
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun SosScreen(viewModel: SosViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_FINE_LOCATION)
    )
    var showAddContactDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
        }
    }

    Column(modifier = Modifier.padding(16.dp)) {
        SosButton(uiState = uiState, onSosTriggered = viewModel::onSosTriggered)
        Spacer(modifier = Modifier.height(16.dp))
        ContactList(contacts = uiState.contacts, onDelete = viewModel::deleteContact)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { showAddContactDialog = true }) {
            Text("Add Contact")
        }
    }

    if (showAddContactDialog) {
        AddContactDialog(
            onAdd = {
                viewModel.addContact(it.first, it.second)
                showAddContactDialog = false
            },
            onDismiss = { showAddContactDialog = false }
        )
    }

    if (uiState.showConfirmationDialog) {
        SosConfirmationDialog(
            onConfirm = viewModel::onSosConfirmed,
            onDismiss = viewModel::onSosDialogDismissed
        )
    }
}

@Composable
private fun SosButton(uiState: SosUiState, onSosTriggered: () -> Unit) {
    Button(
        onClick = onSosTriggered,
        enabled = !uiState.isCooldown && uiState.contacts.isNotEmpty(),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
        modifier = Modifier.fillMaxWidth().height(100.dp)
    ) {
        Text(if (uiState.isCooldown) "SOS on Cooldown" else "TRIGGER SOS", style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
private fun ContactList(contacts: List<com.example.stresssense.data.local.TrustedContact>, onDelete: (com.example.stresssense.data.local.TrustedContact) -> Unit) {
    LazyColumn {
        items(contacts) { contact ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${contact.name} - ${contact.phoneNumber}", modifier = Modifier.weight(1f))
                IconButton(onClick = { onDelete(contact) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Contact")
                }
            }
        }
    }
}

@Composable
private fun AddContactDialog(onAdd: (Pair<String, String>) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Trusted Contact") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") })
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") })
            }
        },
        confirmButton = {
            Button(onClick = { onAdd(name to phone) }) {
                Text("Add")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun SosConfirmationDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Confirm SOS?") },
        text = { Text("This will send a distress message with your location to your trusted contacts.") },
        confirmButton = {
            Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) {
                Text("SEND NOW")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
