package com.example.stresssense.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.stresssense.data.local.SensorDataDao
import com.example.stresssense.data.local.StressPredictionDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import com.example.stresssense.dashboard.DashboardUiState

@HiltViewModel
class DashboardViewModel @Inject constructor(
    stressPredictionDao: StressPredictionDao,
    sensorDataDao: SensorDataDao
) : ViewModel() {

    private val _uiState: StateFlow<DashboardUiState> =
        stressPredictionDao.getPredictionsSince(
            System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
        )
            .map { predictions ->

                val weeklyPredictions = predictions.filter {
                    it.timestamp >= System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7)
                }

                DashboardUiState(
                    currentStressLevel = predictions.firstOrNull()?.stressScore ?: 0f,
                    todaySteps = 0L, // TODO replace with real value
                    todaySleep = "N/A",

                    // SAFE LISTS
                    weeklyStressData =
                        if (weeklyPredictions.size >= 2)
                            weeklyPredictions.map { it.stressScore }
                        else emptyList(),

                    monthlyStressData =
                        if (predictions.size >= 2)
                            predictions.map { it.stressScore }
                        else emptyList()
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = DashboardUiState()
            )

    val uiState: StateFlow<DashboardUiState> get() = _uiState
}
