package com.example.stresssense.sos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.stresssense.data.local.TrustedContact
import com.example.stresssense.data.local.TrustedContactDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SosViewModel @Inject constructor(
    private val trustedContactDao: TrustedContactDao,
    private val sosManager: SosManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(SosUiState())
    val uiState = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            trustedContactDao.getAllContacts().collect {
                _uiState.value = _uiState.value.copy(contacts = it)
            }
        }
    }

    fun onSosTriggered() {
        if (_uiState.value.isCooldown) return
        _uiState.value = _uiState.value.copy(showConfirmationDialog = true)
    }

    fun onSosConfirmed() {
        _uiState.value = _uiState.value.copy(showConfirmationDialog = false)
        viewModelScope.launch {
            sosManager.sendSosMessages()
            startCooldown()
        }
    }

    fun onSosDialogDismissed() {
        _uiState.value = _uiState.value.copy(showConfirmationDialog = false)
    }

    fun addContact(name: String, phone: String) {
        viewModelScope.launch {
            trustedContactDao.insert(TrustedContact(name = name, phoneNumber = phone))
        }
    }

    fun deleteContact(contact: TrustedContact) {
        viewModelScope.launch {
            trustedContactDao.delete(contact)
        }
    }

    private fun startCooldown() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isCooldown = true)
            delay(COOLDOWN_PERIOD_MS)
            _uiState.value = _uiState.value.copy(isCooldown = false)
        }
    }

    companion object {
        private const val COOLDOWN_PERIOD_MS = 60_000L // 1 minute
    }
}

data class SosUiState(
    val contacts: List<TrustedContact> = emptyList(),
    val showConfirmationDialog: Boolean = false,
    val isCooldown: Boolean = false
)
