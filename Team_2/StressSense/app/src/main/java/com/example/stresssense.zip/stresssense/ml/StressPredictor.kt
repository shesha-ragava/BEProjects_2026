package com.example.stresssense.ml

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.io.Closeable
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * A wrapper for the TFLite stress prediction model.
 *
 * This class is responsible for loading the model, performing inference, and returning the result.
 * It dynamically reads the input and output tensor specifications from the model itself,
 * making it more robust to model changes.
 */
@Singleton
class StressPredictor @Inject constructor(
    @ApplicationContext private val context: Context
) : Closeable {

    private var interpreter: Interpreter?
    private val inputTensorShape: IntArray
    private val outputTensorShape: IntArray
    private val inputTensorDataType: DataType
    private val outputTensorDataType: DataType

    init {
        try {
            val model = FileUtil.loadMappedFile(context, MODEL_PATH)
            interpreter = Interpreter(model, Interpreter.Options()).also {
                // Get input tensor details from the model
                val inputTensor = it.getInputTensor(0)
                inputTensorShape = inputTensor.shape()
                inputTensorDataType = inputTensor.dataType()

                // Get output tensor details from the model
                val outputTensor = it.getOutputTensor(0)
                outputTensorShape = outputTensor.shape()
                outputTensorDataType = outputTensor.dataType()
            }
        } catch (e: Exception) {
            throw StressPredictorInitializationException("Failed to initialize StressPredictor", e)
        }
    }

    /**
     * Performs inference on the given input data.
     *
     * @param inputData A 2D FloatArray matching the model's expected input shape.
     * For example: `arrayOf(floatArrayOf(heartRate, steps, motion, sleep))`
     * @return A [Result] containing the stress prediction as a Float on success, or an Exception on failure.
     */
    fun predict(inputData: Array<FloatArray>): Result<Float> {
        val currentInterpreter = interpreter ?: return Result.failure(IllegalStateException("Interpreter is not initialized or has been closed."))

        return try {
            // 1. Allocate buffer for input and fill it
            val inputBuffer = ByteBuffer.allocateDirect(inputTensorShape.fold(1, Int::times) * inputTensorDataType.byteSize())
                .apply {
                    order(ByteOrder.nativeOrder())
                    for (row in inputData) {
                        for (value in row) {
                            putFloat(value)
                        }
                    }
                    rewind()
                }

            // 2. Allocate buffer for output
            val outputBuffer = ByteBuffer.allocateDirect(outputTensorShape.fold(1, Int::times) * outputTensorDataType.byteSize())
                .apply {
                    order(ByteOrder.nativeOrder())
                }

            // 3. Run inference
            currentInterpreter.run(inputBuffer, outputBuffer)

            // 4. Process the output
            outputBuffer.rewind()
            val prediction = outputBuffer.asFloatBuffer().get()

            Result.success(prediction)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Releases resources used by the TFLite interpreter.
     * Since this is a Singleton, this should ideally be called when the application is terminating.
     */
    override fun close() {
        interpreter?.close()
        interpreter = null
    }

    companion object {
        // Ensure your model file in app/src/main/assets has this name
        private const val MODEL_PATH = "stress_model.tflite"
    }
}

class StressPredictorInitializationException(message: String, cause: Throwable? = null) : Exception(message, cause)
