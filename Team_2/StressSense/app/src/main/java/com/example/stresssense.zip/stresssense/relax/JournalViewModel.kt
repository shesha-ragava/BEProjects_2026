package com.example.stresssense.relax

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.stresssense.data.local.JournalEntry
import com.example.stresssense.data.local.JournalEntryDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class JournalViewModel @Inject constructor(
    private val journalEntryDao: JournalEntryDao
) : ViewModel() {

    val journalEntries = journalEntryDao.getAllEntries()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addJournalEntry(mood: String, note: String) {
        viewModelScope.launch {
            if (mood.isNotBlank() || note.isNotBlank()) {
                journalEntryDao.insert(
                    JournalEntry(
                        timestamp = System.currentTimeMillis(),
                        mood = mood,
                        note = note
                    )
                )
            }
        }
    }
}
