package com.example.stresssense.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StressPredictionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(prediction: StressPrediction)

    @Query("SELECT * FROM stress_predictions ORDER BY timestamp DESC")
    fun getAllPredictions(): Flow<List<StressPrediction>>

    @Query("SELECT * FROM stress_predictions WHERE timestamp >= :startTime ORDER BY timestamp DESC")
    fun getPredictionsSince(startTime: Long): Flow<List<StressPrediction>>
}
